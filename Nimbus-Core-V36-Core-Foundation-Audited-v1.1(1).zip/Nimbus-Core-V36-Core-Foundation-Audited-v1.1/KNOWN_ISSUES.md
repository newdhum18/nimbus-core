# Known Issues

## K-001 — D1 database ID placeholder
Severity: Blocking for live deployment

File:
`wrangler.worker.jsonc`

Required action:
Replace `REPLACE_WITH_APPROVED_D1_DATABASE_ID` with the actual ID for `nimbus-core-v36-db`.

## K-002 — Live deployment not executed
Severity: Blocking for final PASS

Required action:
Deploy after K-001 is resolved and run health, bindings, D1 and Queue tests.

## K-003 — Queue failure paths pending
Severity: Non-blocking for architecture acceptance

Pending:
- Retry test
- Maximum retries test
- Dead task test
- Lease recovery test
- Duplicate delivery test

## K-004 — Feature Matrix is not final
Severity: Blocking for full feature implementation

Reason:
The exact final KEEP/REWRITE/REMOVE/DEFER matrix still requires final review of all supplied historical packages.
