import { ok, fail } from "./api/responses.js";
import { AppError, errorDetails } from "./api/errors.js";
import { corsHeaders } from "./api/cors.js";
import { SYSTEM } from "./config.js";
import { health, bindings } from "./diagnostics/health.js";
import { diagnostics } from "./diagnostics/report.js";
import { sourceCatalog } from "./sources/catalog.js";
import { seedSources } from "./sources/defaults.js";
import { startRun } from "./runs/start.js";
import { pauseRun } from "./runs/pause.js";
import { resumeRun } from "./runs/resume.js";
import { cancelRun } from "./runs/cancel.js";
import { dispatchPending } from "./queue/producer.js";

async function requestBody(request) {
  return request.json().catch(() => ({}));
}

function runActionRoute(pathname) {
  return /^\/api\/runs\/([^/]+)\/(pause|resume|cancel|dispatch)$/.exec(pathname);
}

function normalizeErrorPayload(details) {
  const nested = details.details && typeof details.details === "object"
    ? details.details
    : {};

  return {
    code: details.code,
    message: details.message,
    component: details.component,
    runId: nested.run_id ?? nested.runId ?? null,
    taskId: nested.task_id ?? nested.taskId ?? null,
    details: details.details
  };
}

export async function route(request, env) {
  const url = new URL(request.url);
  const cors = corsHeaders(request);

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: cors });
  }

  try {
    if (url.pathname === "/" && request.method === "GET") {
      return ok({
        system: SYSTEM,
        endpoints: ["/health", "/bindings", "/api/status", "/api/diagnostics"]
      }, 200, cors);
    }

    if (url.pathname === "/health" && request.method === "GET") {
      return ok(health(), 200, cors);
    }

    if (url.pathname === "/bindings" && request.method === "GET") {
      return ok(bindings(env), 200, cors);
    }

    if (url.pathname === "/api/status" && request.method === "GET") {
      return ok({ system: SYSTEM, bindings: bindings(env) }, 200, cors);
    }

    if (url.pathname === "/api/diagnostics" && request.method === "GET") {
      return ok(await diagnostics(env), 200, cors);
    }

    if (url.pathname === "/api/foundation/db-test" && request.method === "GET") {
      if (!env.DB) {
        throw new AppError("DB_BINDING_UNAVAILABLE", "D1 binding is unavailable", "d1", 503);
      }
      const value = (await env.DB.prepare("SELECT 1 value").first())?.value;
      return ok({ component: "d1", value }, 200, cors);
    }

    if (url.pathname === "/api/sources/catalog" && request.method === "GET") {
      const catalog = sourceCatalog();
      return ok({
        total: catalog.length,
        enabled: catalog.filter((source) => source.enabled).length
      }, 200, cors);
    }

    if (url.pathname === "/api/sources" && request.method === "GET") {
      const rows = await env.DB.prepare(`
        SELECT *
        FROM sources
        ORDER BY enabled DESC,priority DESC
        LIMIT 300
      `).all();
      return ok({
        total: rows.results?.length || 0,
        sources: rows.results || []
      }, 200, cors);
    }

    if (url.pathname === "/api/sources/reset" && request.method === "POST") {
      return ok(await seedSources(env.DB, { preserveEnabled: false }), 200, cors);
    }

    if (url.pathname === "/api/runs/start" && request.method === "POST") {
      const data = await requestBody(request);
      if (!["autoscan", "keyword"].includes(data.mode)) {
        throw new AppError(
          "INVALID_MODE",
          "mode must be autoscan or keyword",
          "runs",
          400
        );
      }
      return ok(await startRun(env, data), 201, cors);
    }

    if (url.pathname === "/api/runs" && request.method === "GET") {
      const rows = await env.DB.prepare(
        "SELECT * FROM runs ORDER BY created_at DESC LIMIT 50"
      ).all();
      return ok({ runs: rows.results || [] }, 200, cors);
    }

    const match = runActionRoute(url.pathname);
    if (match && request.method === "POST") {
      const [, runId, action] = match;
      let result;

      if (action === "pause") result = await pauseRun(env.DB, runId);
      if (action === "resume") result = await resumeRun(env, runId);
      if (action === "cancel") result = await cancelRun(env.DB, runId);
      if (action === "dispatch") result = await dispatchPending(env, runId, 20);

      if (result === false) {
        throw new AppError(
          "RUN_STATE_CONFLICT",
          `Cannot ${action} run in its current state`,
          "runs",
          409,
          { run_id: runId }
        );
      }

      return ok({ run_id: runId, action, result }, 200, cors);
    }

    const knownPath = [
      "/", "/health", "/bindings", "/api/status", "/api/diagnostics",
      "/api/foundation/db-test", "/api/sources/catalog", "/api/sources",
      "/api/sources/reset", "/api/runs/start", "/api/runs"
    ].includes(url.pathname) || Boolean(match);

    if (knownPath) {
      return fail({
        code: "METHOD_NOT_ALLOWED",
        message: "The HTTP method is not allowed for this endpoint",
        component: "router"
      }, 405, cors);
    }

    return fail({
      code: "NOT_FOUND",
      message: "The requested endpoint does not exist",
      component: "router"
    }, 404, cors);
  } catch (error) {
    const details = errorDetails(error);
    return fail(normalizeErrorPayload(details), details.status, cors);
  }
}
