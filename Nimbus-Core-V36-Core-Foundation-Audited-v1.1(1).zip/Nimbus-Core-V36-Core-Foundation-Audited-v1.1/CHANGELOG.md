# Changelog

## Candidate 2 — 2026-07-11

Corrected from Draft 1:

- Removed committed `dist/`.
- Removed duplicate package inventory source.
- Added strict CORS origin validation.
- Preserved CORS headers on error responses.
- Added HTTP 405 handling.
- Added npm/Wrangler dependency policy.
- Added configuration and release validators.
- Added `queued_at` and `updated_at` task fields.
- Changed link uniqueness to `(run_id, normalized_url)`.
- Added global normalized-link index.
- Added run progress synchronization.
- Added automatic initial dispatch on run start.
- Added batch Queue dispatch with rollback.
- Corrected Resume so queued tasks are not blindly replayed.
- Added paused/cancelled run handling in Queue consumer.
- Corrected page upsert/reference behavior.
- Added visited URL updates.
- Added source metric recording.
- Added event recording.
- Corrected source reset to update `enabled`.
- Hardened MEGA decoding and entity handling.
- Added public-URL validation and response-size limits.
- Removed incomplete Repair DB endpoint from current phase.
- Added documented release gate for D1 database ID.


## Audited v1.1

- Removed generated `dist/` from the source package.
- Removed `node_modules/` and `.wrangler/` from the source package.
- Regenerated a single authoritative file inventory.
- Added verified 45-test result.
- Added Worker dry-run result.
- Added local D1 idempotency result.
- Documented the real D1 database ID as the only release placeholder.
- Corrected phase status and release classification.
